import React from 'react'

function Greet()
{
    return <h1>Hello Hritik</h1>
}

export default Greet 