import React from "react";

const About = () =>
{
    return <h1>Hello, I am in About Page</h1>;
}

export default About;