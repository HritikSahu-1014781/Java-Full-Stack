import React from "react";

const Contact = () =>
{
    return <h1>Hello, I am in Contact Page</h1>;
}

export default Contact;