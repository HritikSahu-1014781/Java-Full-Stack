import React, {Component} from 'react';
class Menu extends Component
{
  render()
  {
    return (
        <div className='Menu'>
            <ul>
            <li>Home</li>
            <li>Login</li>          
            <li>About Us</li>
            <li>Contact Us</li>
            </ul>
        </div>

    );
  }
}
export default Menu