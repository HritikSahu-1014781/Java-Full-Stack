import React from "react";

function Image ()
{
   return <img className="image" src="https://ravenintel.com/wp-content/uploads/2018/01/yash3.png"></img>
}

export default Image;