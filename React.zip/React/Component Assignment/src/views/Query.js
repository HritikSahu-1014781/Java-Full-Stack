import React from "react";

function Query()
{
    return <h1>Query</h1>
}

export default Query;