import React, { Component } from 'react';
import './App.css';
import Logo from './views/Logo';
import Image from './views/Image';
import Menu from './views/Menu';
import Query from './views/Query';
import Component1 from './views/Component1';
import Component2 from './views/Component2';

class App extends Component {
  render() {
    return (
      <div className="App">
        <table>
          <tr>
            <td>
              <Logo />
            </td>
            <td rowSpan={"2"} colSpan={"2"}>
              <Image />
            </td>
          </tr>
          <tr>
            <td>
              <Menu />
            </td>
          </tr>
          <tr>
            <td>
              <Query />
            </td>
            <td>
              <Component1 />
            </td>
            <td>
              <Component2 />
            </td>
          </tr>
        </table>
      </div >
    );
  }
}

export default App;
