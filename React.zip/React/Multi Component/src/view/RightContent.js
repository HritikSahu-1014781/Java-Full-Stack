import React, {Component} from 'react';
class RightContent extends Component
{
  render()
  {
    return (
        <div className='rcontent'>
                 
  left content
        </div>

    );
  }
}
export default RightContent