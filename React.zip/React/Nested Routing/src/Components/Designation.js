import React from 'react';

function Designation()
{
    return <h1>Associate Trainee</h1>
}

export default Designation;