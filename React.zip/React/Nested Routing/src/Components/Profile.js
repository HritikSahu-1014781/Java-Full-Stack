import React from 'react';
import {Link,Outlet} from 'react-router-dom'

function Profile()
{
    return <div><Link to="/profile/name">Name</Link><Link to="/profile/designation">Designation</Link><Outlet/></div>
}

export default Profile;