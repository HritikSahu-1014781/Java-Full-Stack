import React from 'react';

function Home()
{
    return <h1>I am in the Home</h1>
}

export default Home;