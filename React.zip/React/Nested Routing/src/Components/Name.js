import React from 'react';

function Name()
{
    return <h1>Hritik Sahu</h1>
}

export default Name;