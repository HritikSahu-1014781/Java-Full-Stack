import React, { Component } from 'react';
import { Route, Routes } from 'react-router-dom';
import Home from './Components/Home';
import Profile from './Components/Profile';
import Name from './Components/Name';
import Designation from './Components/Designation';
import { Link } from "react-router-dom";
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Link to="/">Home</Link>
        <Link to="/profile">Profile</Link>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/profile' element={<Profile />}>
            <Route path='name' element={<Name />} />
            <Route path='designation' element={<Designation />} />
          </Route>
        </Routes>
      </div>
    );
  }
}

export default App;
