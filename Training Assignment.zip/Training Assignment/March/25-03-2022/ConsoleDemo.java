import java.io.Console;

class ConsoleDemo
{
	public static void main(String [] args)
	{
		Console c=System.console();
		System.out.println("Enter Username: ");
		String username=c.readLine();
		
		System.out.println("Enter Password: ");
		char[] password=c.readPassword();
		
		System.out.println("Username: "+username+"\nPassword: "+String.valueOf(password));
	}
}