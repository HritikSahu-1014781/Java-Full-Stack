package com.automobile;
public abstract class Vehicle
{
    public abstract String getName();
}