package com.automobile.twowheeler;
import com.automobile.*;

public class Honda extends Vehicle
{
	public int getSpeed()
	{
		int speed=100;
		return speed;
	}
	
	public void cdPlayer()
	{
		System.out.println("CD Player control provider.");
	}

}