import java.io.BufferedReader;
import java.io.InputStreamReader;

class Buffer
{
	public static void main(String [] args) throws Exception
	{
		InputStreamReader input=new InputStreamReader(System.in);
		BufferedReader buffer=new BufferedReader(input);
		String name=buffer.readLine();
		
		System.out.println(name);
	}
}