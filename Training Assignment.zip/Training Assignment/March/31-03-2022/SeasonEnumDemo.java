class SeasonEnumDemo
{
	enum Season
	{
		Winter,
		Summer,
		Rainy,
		Spring;
	}
	
	public static void main(String [] args)
	{
		for(Season s:Season.values())
		{
			System.out.println(s);
		}
	}
}