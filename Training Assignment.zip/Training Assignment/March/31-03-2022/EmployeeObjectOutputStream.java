import java.io.*;

class Employee implements Serializable
{
	int empId;
	String empName;
	Employee(int empId,String empName)
	{
		this.empId=empId;
		this.empName=empName;
	}
	public String toString()
	{
		return empId+" "+empName;
	}
}

class EmployeeObjectOutputDemo 
{
	public static void main(String [] args) throws IOException
	{
		Employee e=new Employee(1,"Hritik");
		System.out.println(e);
		File f=new File("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/31-03-2022/abc.txt");
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();		
	}
}