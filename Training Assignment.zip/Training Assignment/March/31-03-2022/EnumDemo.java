class EnumDemo
{
	enum Speed
	{
		HIGH(100),
		MEDIUM(50),
		LOW(10),
		STOP(0);
		
		int val;
		Speed(int val)
		{
			this.val=val;
		}
	}
	
	public static void main(String [] args)
	{
		for(Speed s:Speed.values())
		{
			System.out.println(s+" "+s.val);
		}
		System.out.println("Value of: "+Speed.valueOf("HIGH"));
		System.out.println("Index of: "+Speed.valueOf("HIGH").ordinal());
	}
}