import java.io.*;

class BufferedOutputStreamDemo
{
	public static void main(String [] args)
	{
		try
		{
			FileOutputStream fout=new FileOutputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/abc.txt");
			BufferedOutputStream bout=new BufferedOutputStream(fout);
			char[] arr=new char[]{'H','e','l','l','o'};
			for(int a: arr)
			{
				bout.write(a);
			}

			bout.close();
			fout.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}