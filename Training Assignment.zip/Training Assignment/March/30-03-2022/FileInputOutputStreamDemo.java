import java.io.*;

class FileInputOutputStreamDemo
{
	public static void main(String [] args) throws IOException
	{
		FileInputStream in=new FileInputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/abc.txt");
		FileOutputStream out=new FileOutputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/xyz.txt",true);
		int c;
		while((c=in.read())!=-1)
		{
			out.write(c);
			System.out.println((char)c);
		}
		in.close();
		out.close();
	}
}