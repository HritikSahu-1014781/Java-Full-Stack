import java.io.*;

class DataInputStreamDemo
{
	public static void main(String [] args) throws IOException
	{
		FileInputStream in=new FileInputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/abc.txt");
		DataInputStream dt=new DataInputStream(in);
		int c;
		while((c=dt.read())!=-1)
		{
			System.out.print((char)c);
		}
		in.close();
		dt.close();
	}
}