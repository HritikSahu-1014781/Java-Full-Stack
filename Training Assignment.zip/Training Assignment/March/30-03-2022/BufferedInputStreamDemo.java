import java.io.*;

class BufferedInputStreamDemo
{
	public static void main(String [] args)
	{
		try
		{
			FileInputStream fin=new FileInputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/abc.txt");
			BufferedInputStream binput=new BufferedInputStream(fin);
			int i;
			while((i=binput.read())!=-1)
			{
				System.out.print((char)i);
			}
			binput.close();
			fin.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}