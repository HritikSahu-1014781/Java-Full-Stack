class ArrayMiddle
{
	public static void main(String [] args)
	{
		int[] arr1=new int[]{1,2,3};
		int[] arr2=new int[]{4,5,6};
		int[] arr3=new int[2];
		
		arr3[0]=arr1[arr1.length/2];
		arr3[1]=arr2[arr2.length/2];
		
		for(int a:arr3)
		{
			System.out.print(a+" ");
		}
	}
}