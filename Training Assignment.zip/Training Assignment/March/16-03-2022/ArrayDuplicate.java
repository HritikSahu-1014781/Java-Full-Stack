class ArrayDuplicate
{
	public static void main(String [] args)
	{
		int[] arr=new int[]{10,20,20,40,30,50,50};
		for(int a=0;a<arr.length;a++)
		{
			for(int b=a+1;b<arr.length;b++)
			{
				if(arr[a]==arr[b])
				{
					arr[b]=0;
				}
			}
		}
		for(int c:arr)
			{
				if(c==0)
					continue;
				System.out.print(c+" ");
			}
	}
}