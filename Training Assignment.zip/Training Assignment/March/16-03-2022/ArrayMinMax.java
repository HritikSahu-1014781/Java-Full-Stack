class ArrayMinMax
{
	public static void main(String [] args)
	{
		int[] arr=new int[]{10,20,90,60,40,50};
		int max=0,min=arr[0];
		for(int a=0;a<arr.length;a++)
		{
			if(arr[a]>max)
				max=arr[a];
			
			if(arr[a]<min)
				min=arr[a];
		}
		System.out.println("Min="+min+",Max="+max);
	}
}