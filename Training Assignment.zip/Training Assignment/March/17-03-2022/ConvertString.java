class ConvertString
{
	public static void main(String [] args)
	{
		String s=args[0];
		
		System.out.println(s.substring(1,s.length()-1));
		
	}
}