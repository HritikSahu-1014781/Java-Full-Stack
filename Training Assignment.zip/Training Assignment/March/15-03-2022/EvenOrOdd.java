class EvenOrOdd
{
public static void main(String [] args)
{
int num1=Integer.parseInt(args[0]);
if(num1!=0)
{
if(num1%2==0)
System.out.println("The number is even");
else
System.out.println("The number is odd");

}
else 
System.out.println("Please enter a number greater than 0");
}
}