class Constructor
{
	Constructor()
	{
		System.out.println("No Argument Constructor");
	}
	Constructor(int a)
	{
		System.out.println("Parameter Constructor: "+a);
	}
	public static void main(String [] args)
	{
		Constructor c1=new Constructor();
		Constructor c2=new Constructor(10);
	}
}