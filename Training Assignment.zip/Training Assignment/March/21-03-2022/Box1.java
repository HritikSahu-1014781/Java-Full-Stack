class Box
{   
    int height = 0;
	int width = 0;
	int depth = 0;
	Box(int height,int width,int depth)
	{
		this.height=height;
		this.width=width;
		this.depth=depth;
		System.out.println("Volume is: "+volume());
	}
	int volume()
	{
		return height*width*depth;
	}
}

class Box1
{
	public static void main(String [] args)
	{
		Box b=new Box(10,20,30);
	} 
}
