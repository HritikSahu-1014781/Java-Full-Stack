class CurrentClassInstance
{
	public static void main(String [] args)
	{
		Demo s=new Demo();
		System.out.println(s.show());
	}
}
class Demo
{
	int i=50;
	int show()
	{
		return this.i;
	}
}
