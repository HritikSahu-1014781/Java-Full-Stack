class Parent
{
	void show()
	{
		System.out.println("I am Parent");
	}
}

class SingleLevel extends Parent
{
	public static void main(String [] args)
	{
		SingleLevel s=new SingleLevel();
		s.show();
	}
}
