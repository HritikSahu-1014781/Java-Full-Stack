class Student
{
    private int roll_no;

    public void setRoll_no(int roll_no)
    {
        this.roll_no=roll_no;
    }

    public int getRoll_no()
    {
        return roll_no;
    }
}

class Teacher
{
    public static void main(String[] args)
    {
        int roll_no=Integer.parseInt(args [0]);
        Student s=new Student();
        s.setRoll_no(roll_no);
        System.out.println(s.getRoll_no());
    }
}