class Fruit
{
	String name;
	String taste;
	String size;
	
	void eat()
	{
	    name="Grapes";
		taste="Sweet";
		size="Small";
		
		System.out.println(name+taste+size);
	}
}

class Apple extends Fruit
{
	void eat()
	{
		name="Apple";
		taste="Sweet";
		size="Medium";
		
		System.out.println(name+taste+size);
	}
}

class Orange extends Fruit
{
	void eat()
	{
		name="Orange";
		taste="Citrus";
		size="Medium";
		
		System.out.println(name+taste+size);
	}
}

class Overriding2
{
	public static void main(String [] args)
	{
		Apple apple=new Apple();
		apple.eat();
		
		Orange orange=new Orange();
		orange.eat();
	}
}