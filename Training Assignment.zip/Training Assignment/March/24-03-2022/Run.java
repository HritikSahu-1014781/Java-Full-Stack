abstract class Animal
{
	abstract void legs();
}

class Bird extends Animal
{
	void legs()
	{
		System.out.println("Bird have 2 legs.");
	}
}

class Cow extends Animal
{
	void legs()
	{
		System.out.println("Bird have 4 legs.");
	}
}

class Run 
{
	public static void main(String [] args)
	{
		Bird b=new Bird();
		b.legs();
		
		Cow c=new Cow();
		c.legs();
	}
}