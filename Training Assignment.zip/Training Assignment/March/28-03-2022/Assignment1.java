class Assignment1
{
	public static void main(String [] args)
	{
		String input=args[0];
		try
		{
			int a=Integer.parseInt(input);
			System.out.println(a*a);
		}
		catch(Exception e)
		{
			System.out.println("Entered input is not a valid format for an integer.");
		}
	}
}