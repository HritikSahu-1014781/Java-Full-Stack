import java.util.Scanner;
class Assignment3
{
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		try
		{
			int size=sc.nextInt();
			System.out.println("Enter array Size: ");
			int[] arr=new int[size];
			System.out.println("Enter array value: ");
			for(int a=0;a<size;a++)
			{
				arr[a]=sc.nextInt();
			}
		
			System.out.println("Enter index to find:");
			System.out.println(arr[sc.nextInt()]);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Index is greater than array size");
		}
		catch(NumberFormatException e)
		{
			System.out.println("Please enter a valid input");
		}
		
	}
}