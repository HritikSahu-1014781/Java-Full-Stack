import java.util.*;

class Marks extends RuntimeException
{
	Marks(String s)
	{
		super(s);
	}
}

class StudentMarks
{
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		String student1name;
		String student2name;
		int student1sum=0;
		int student2sum=0;
		try
		{
			System.out.println("Enter first student name: ");
			student1name=sc.nextLine();
			System.out.println("Enter marks of first student: ");
			for(int a=0;a<3;a++)
			{
				int b=sc.nextInt();
				if(b>100&&b<0)
				{
					throw new Marks("Marks are not valid");
				}
				else
				{
					student1sum=student1sum+b;
				}
			}
			
			System.out.println("Enter second student name: ");
			sc.nextLine();
			student2name=sc.nextLine();
			System.out.println("Enter marks of second student: ");
			for(int a=0;a<3;a++)
			{
				int b=sc.nextInt();
				if(b>100&&b<0)
				{
					throw new Marks("Marks are not valid");
				}
				else
				{
					student2sum=student2sum+b;
				}
			}
			System.out.println("Student1 total marks: "+student1sum+" and average is: "+student1sum/3);
			System.out.println("Student1 total marks: "+student2sum+" and average is: "+student2sum/3);
		}
		catch(InputMismatchException e)
		{
			System.out.print("Please enter valid marks.");
		}
	}
}