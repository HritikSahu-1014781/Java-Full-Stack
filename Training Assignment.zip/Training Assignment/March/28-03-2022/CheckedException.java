import java.io.FileInputStream;

class CheckedException
{
	public static void main(String [] args)
	{
		FileInputStream f=new FileInputStream("Hello.java");
	}
}