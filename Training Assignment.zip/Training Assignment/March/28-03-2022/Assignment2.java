import java.util.Scanner;
class Assignment2
{
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		System.out.println("Enter array Size: ");
		int[] arr=new int[size];
		System.out.println("Enter array value: ");
		for(int a=0;a<size;a++)
		{
			arr[a]=sc.nextInt();
		}
		try
		{
			System.out.println(arr[sc.nextInt()]);
		}
		catch(Exception e)
		{
			System.out.println("Please enter a valid input");
		}
		
	}
}