import java.util.Random;

abstract class Compartment
{
	public abstract String notice();
}

class FirstClass extends Compartment
{
	public String notice()
	{
		String s="This is First Class.";
		return s;
	}
}

class Ladies extends Compartment
{
	public String notice()
	{
		String s="This is Ladies Compartment.";
		return s;
	}
}

class General extends Compartment
{
	public String notice()
	{
		String s="This is General Compartment.";
		return s;
	}
}

class Luggage extends Compartment
{
	public String notice()
	{
		String s="This is Luggage Compartment.";
		return s;
	}
}

class TestCompartment
{
	public static void main(String [] args)
	{
		Compartment[] cmp=new Compartment[10];
		
		for(int a=0;a<10;a++)
		{
			int b=(new Random()).nextInt(4)+1;
			if(b==1)
			{
				cmp[a]=new FirstClass();
			}
			if(b==2)
			{
				cmp[a]=new Ladies();
			}
			if(b==3)
			{
				cmp[a]=new General();
			}
			if(b==4)
			{
				cmp[a]=new Luggage();
			}
		}
		for(int a=0;a<10;a++)
		{
			System.out.println((a+1)+" Compartment - "+cmp[a].notice());
		}
	}
}