class OuterClass
{
	static class InnerClass1
	{
		void show()
		{
			System.out.println("I am in static class");
		}
	}
	class InnerClass2
	{
	    void show()
		{
			System.out.println("I am in non-static class");
		}
	}
}
class OuterDemo
{
	public static void main(String [] args)
	{
		OuterClass.InnerClass1 oi=new OuterClass.InnerClass1();
		oi.show();
		
		OuterClass o=new OuterClass();
		OuterClass.InnerClass2 i=o.new InnerClass2();
		i.show();
	}
}