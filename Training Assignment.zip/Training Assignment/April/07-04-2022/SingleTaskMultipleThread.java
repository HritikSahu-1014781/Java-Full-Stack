class SingleTaskMultipleThread extends Thread
{
	public void run()
	{
		System.out.println("Thread is Working Now!");
	}
	public static void main(String [] args)
	{
		SingleTaskMultipleThread t=new SingleTaskMultipleThread();
		t.start();
		SingleTaskMultipleThread t2=new SingleTaskMultipleThread();
		t2.start();
	}
}