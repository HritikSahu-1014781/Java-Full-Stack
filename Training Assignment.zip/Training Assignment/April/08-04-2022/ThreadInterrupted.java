class ThreadInterrupted extends Thread
{
	public void run()
	{
		//System.out.println(Thread.interrupted());
		try
		{
			//System.out.println(Thread.interrupted());
			for(int i=1;i<=5;i++)
			{
				System.out.println(Thread.interrupted());
				System.out.println("I am Thread "+i);
				Thread.currentThread().sleep(300);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String [] args)
	{
		ThreadInterrupted t=new ThreadInterrupted();
		t.start();
		t.interrupt();
	}
}