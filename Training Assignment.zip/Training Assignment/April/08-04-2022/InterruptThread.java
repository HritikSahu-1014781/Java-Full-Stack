class InterruptThread extends Thread
{
	public void run()
	{
		try
		{
			for(int i=1;i<=5;i++)
			{
				System.out.println("I am Thread "+i);
				Thread.currentThread().sleep(300);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String [] args)
	{
		InterruptThread t=new InterruptThread();
		t.start();
		t.interrupt();
	}
}