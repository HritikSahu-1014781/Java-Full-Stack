class BookTicket
{
	int totalSeats=12;
	void bookSeats(int seats)
	{
		synchronized(this)
		{
			if(totalSeats>=seats)
			{
				System.out.println("Ticket Booked Successfully!");
				totalSeats=totalSeats-seats;
				System.out.println("Remaining seats: "+totalSeats);
			}
			else
			{
				System.out.println("Seats are not available: "+totalSeats);
			}
		}
	}
}

class SynchronizedBlockDemo extends Thread
{
	static BookTicket b;
	public void run()
	{
		b.bookSeats(8);
	}
	public static void main(String [] args)
	{
		b=new BookTicket();
		SynchronizedBlockDemo t1=new SynchronizedBlockDemo();
		t1.start();
		SynchronizedBlockDemo t2=new SynchronizedBlockDemo();
		t2.start();
		
	}
}