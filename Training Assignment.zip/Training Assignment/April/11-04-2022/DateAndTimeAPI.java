import java.time.*;
class DateAndTimeAPI
{
	public static void main(String [] args)
	{
		LocalDate date = LocalDate.now();
		System.out.println("the current date is "+date);
	  
		LocalTime time = LocalTime.now();
		System.out.println("the current time is "+time);
		
		LocalDateTime current = LocalDateTime.now();
		System.out.println("current date and time : "+current);
	}
}