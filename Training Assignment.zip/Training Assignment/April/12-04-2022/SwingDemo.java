import javax.swing.*;
class SwingDemo
{
	public static void main(String [] args)
	{
		JFrame f= new JFrame();  
		f.setSize(800,800);  
	
		JTextField t=new JTextField();  
		t.setBounds(10,10, 40,30);  
		f.add(t);
		
		JButton b=new JButton("Click Here");  
		b.setBounds(50,100,95,30);  
		f.add(b);

		JCheckBox checkBox = new JCheckBox("Java");  
        checkBox.setBounds(300,100, 50,50);  
        f.add(checkBox); 

        JRadioButton r1=new JRadioButton("Hello");  
		r1.setBounds(75,50,100,30);
		f.add(r1);
		
		JScrollBar s=new JScrollBar();  
		s.setBounds(100,100, 50,100);  
		f.add(s);  
	
		f.setLayout(null);  
		f.setVisible(true);  
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}