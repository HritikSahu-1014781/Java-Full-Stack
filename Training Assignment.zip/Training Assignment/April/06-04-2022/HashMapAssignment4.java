import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Map;
import java.util.ArrayList;

class HashMapAssignment4
{
	static HashMap<String,String> m1=new HashMap<String,String>();
	
	static HashMap saveCountryCapital(String countryName,String capital)
	{
		m1.put(countryName,capital);
		return m1;
	}
	
	static String getCapital(String countryName)
	{
		Iterator i=(m1.entrySet()).iterator();
		while(i.hasNext())
		{
			Map.Entry e=(Map.Entry)i.next();
			if((e.getKey()).equals(countryName))
			{
				return (String)e.getValue();
			}
		}
		return "Capital Not Found!";
	}
	
	static String getCountry(String capitalName)
	{
		Iterator i=(m1.entrySet()).iterator();
		while(i.hasNext())
		{
			Map.Entry e=(Map.Entry)i.next();
			if((e.getValue()).equals(capitalName))
			{
				return (String)e.getKey();
			}
		}
		return "Country Not Found!";
	}
	
	static ArrayList getArrayListOfCountries()
	{
		ArrayList<String> arr=new ArrayList<String>();
		for(String i : m1.keySet())
		{
			arr.add(i);
		}
		return arr;
	}
	
	static HashMap newHashMap()
	{
		HashMap<String,String> m2=new HashMap<String,String>();
		Iterator i=(m1.entrySet()).iterator();
		while(i.hasNext())
		{
			Map.Entry e=(Map.Entry)i.next();
			m2.put((String)e.getValue(),(String)e.getKey());
		}
		return m2;
	}
	
	public static void main(String [] args)
	{
		saveCountryCapital("India","Delhi");
		System.out.println(getCapital("India"));
		System.out.println(getCountry("Delhi"));
		System.out.println(getArrayListOfCountries());
		System.out.println(newHashMap());
	}
}