import java.util.Vector;
import java.util.Iterator;
class VectorListOfMonths
{
	public static void main(String [] args)
	{
		Vector<String> arr=new Vector<String>();
		arr.add("January");
		arr.add("Febraury");
		arr.add("March");
		arr.add("April");
		arr.add("May");
		arr.add("June");
		arr.add("July");
		arr.add("August");
		arr.add("September");
		arr.add("Octomber");
		arr.add("November");
		arr.add("December");
	
		System.out.println(arr);
	}
}