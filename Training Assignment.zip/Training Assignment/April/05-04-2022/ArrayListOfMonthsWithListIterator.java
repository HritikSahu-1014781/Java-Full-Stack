import java.util.ArrayList;
import java.util.ListIterator;
class ArrayListOfMonthsWithListIterator
{
	public static void main(String [] args)
	{
		ArrayList<String> arr=new ArrayList<String>();
		ListIterator li=arr.listIterator();
		li.add("January");
		li.add("Febraury");
		li.add("March");
		li.add("April");
		li.add("May");
		li.add("June");
		li.add("July");
		li.add("August");
		li.add("September");
		li.add("Octomber");
		li.add("November");
		li.add("December");
	
		System.out.println(arr);
		
		for(String s: arr)
		{
			System.out.println(s);
		}
	}
}