import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

class HashSetAssignment2
{
	public static void main(String [] args)
	{
		HashSet<String> hs=new HashSet<String>();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("\nPress 1 to store a employee name");
			System.out.println("Press 2 to show all employee name");
			System.out.println("Press 3 to Exit");
			int option=sc.nextInt();
			switch(option)
			{
				case 1: System.out.println("\nPlease enter the name of emplyoee:");
					    hs.add(sc.next());
					    System.out.println("employee name saved successfully!\n");
					    break;
					   
				case 2: System.out.println("\nAll the employees are:");
						Iterator i=hs.iterator();
						while(i.hasNext())
						{
							System.out.println(i.next());
						}
					   break;
			}
			if(option==3)
			{
				break;
			}
		}
	}
}