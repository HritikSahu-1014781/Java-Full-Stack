import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;
class ArrayListDataTypeAssignment
{
	public static void main(String [] args)
	{
		ArrayList<Number> arr=new ArrayList<Number>();
		Scanner sc=new Scanner(System.in);
		int option;
		int count=0;
		while(true)
		{
			try
			{
				System.out.println("Press 1 to store a Integer");
				System.out.println("Press 2 to store a float");
				System.out.println("Press 3 to store a double");
				System.out.println("Press 4 to view all");
				System.out.println("Press 5 to Exit");
			    if(count>0)
				{
					sc.nextLine();
				}
				option=sc.nextInt();
			
				
				switch(option)
				{
					case 1: System.out.println("\nPlease enter the Integer value: ");
							arr.add(sc.nextInt());
							System.out.println("Integer saved successfully!\n");
							break;
						   
					case 2: System.out.println("\nPlease enter the Float value: ");
							arr.add(sc.nextFloat());
							System.out.println("Float saved successfully!\n");
							break;
							
					case 3: System.out.println("\nPlease enter the Double value: ");
							arr.add(sc.nextDouble());
							System.out.println("Double saved successfully!\n");
							break;
							
					case 4: System.out.println("\nAll the Values are: ");
							Iterator i=arr.iterator();
							while(i.hasNext())
							{
								System.out.println(i.next());
							}
							break;
				}
				if(option==5)
				{
					break;
				}
			}
			catch(InputMismatchException e)
			{
				System.out.println("Please enter correct Input");
				count++;
			}
		}
	}
}