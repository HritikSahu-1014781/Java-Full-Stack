import java.util.HashSet;
import java.util.Iterator;
class HashSetListOfMonths
{
	public static void main(String [] args)
	{
		HashSet<String> arr=new HashSet<String>();
		arr.add("January");
		arr.add("Febraury");
		arr.add("March");
		arr.add("April");
		arr.add("May");
		arr.add("June");
		arr.add("July");
		arr.add("August");
		arr.add("September");
		arr.add("Octomber");
		arr.add("November");
		arr.add("December");
	
		System.out.println(arr);
	}
}