import java.util.LinkedList;
import java.util.Iterator;
class LinkedListOfMonths
{
	public static void main(String [] args)
	{
		LinkedList<String> arr=new LinkedList<String>();
		arr.add("January");
		arr.add("Febraury");
		arr.add("March");
		arr.add("April");
		arr.add("May");
		arr.add("June");
		arr.add("July");
		arr.add("August");
		arr.add("September");
		arr.add("Octomber");
		arr.add("November");
		arr.add("December");
	
		System.out.println(arr);
	}
}