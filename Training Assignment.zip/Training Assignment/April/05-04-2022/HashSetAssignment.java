import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
class HashSetAssignment
{
	static HashSet<String> H1=new HashSet<>();
	
	static HashSet saveCountryNames(String countryName)
	{
		H1.add(countryName);
		return H1;
	}
	
	static String getCountry(String countryName2)
	{
		Iterator i=H1.iterator();
		while(i.hasNext())
		{
            if((i.next()).equals(countryName2))
			{
				return "Country Found\n";
			}
		}
		return "No country found\n";
	}
	
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
	
		while(true)
		{
			System.out.println("Press 1 to store a city");
			System.out.println("Press 2 to find a city");
			System.out.println("Press 3 to Exit");
			int option=sc.nextInt();
			switch(option)
			{
				case 1:System.out.println("Please enter the name of city:");
				       saveCountryNames(sc.next());
					   System.out.println("City saved successfully!\n");
					   break;
					   
				case 2:System.out.println("Please enter the name of city which you want to find:");
					   System.out.println(getCountry(sc.next()));
					   break;
			}
			if(option==3)
			{
				break;
			}
		}
	}
}