import java.sql.*;
import java.io.*;
class UpdateWithBufferedReaderInDB
{
	public static void main(String [] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/yash_technologies","root","root");
			
			PreparedStatement ps=con.prepareStatement("update employee set empID=(?),name=(?) where empID=1004");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("Enter the employee ID: ");
			ps.setInt(1,Integer.parseInt(br.readLine()));
			System.out.println("Enter the employee Name: ");
			ps.setString(2,br.readLine());
			ps.executeUpdate();
			
			System.out.println("Insert Successfully..");
			
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}