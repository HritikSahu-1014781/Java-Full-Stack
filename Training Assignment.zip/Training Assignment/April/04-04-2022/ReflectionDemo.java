import java.lang.reflect.*;

class ReflectionTest
{
	private int a=10;
	ReflectionTest()
	{
		System.out.println("This is Constructor.");
	}
	void show()
	{
		System.out.println(a);
	}
}

class ReflectionDemo
{
	public static void main(String [] args) throws Exception
	{
		Class c=Class.forName("ReflectionTest");   
		
		System.out.println(c.getName()); 
		
		Method[] methods = c.getMethods();
        for (Method method:methods)
		{
            System.out.println(method.getName());
		}
		
		Constructor constructor = c.getConstructor();
        System.out.println("The name of constructor is " +constructor.getName());
	}
}