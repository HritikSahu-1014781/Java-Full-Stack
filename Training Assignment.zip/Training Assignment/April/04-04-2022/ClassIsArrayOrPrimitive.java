import java.lang.Class;
class ClassTest{}
interface InterfaceTest{}

class ClassIsArrayOrPrimitive
{
	public static void main(String [] args) throws Exception
	{
		Class class1 = Class.forName("ClassTest");
		System.out.println(class1.isInterface());
	
		Class class2 = Class.forName("InterfaceTest");
		System.out.println(class2.isInterface());
		
		System.out.println(class1.isArray());
		System.out.println(class1.isPrimitive());
	}
}