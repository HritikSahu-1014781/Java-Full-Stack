package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.dao.BookDao;
import com.yash.dto.BookDto;

@WebServlet("/BookCourier")
public class BookCourier extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BookCourier() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String name = request.getParameter("name");
		String type = request.getParameter("type");
		String pickup = request.getParameter("pickupLocation");
		String destination = request.getParameter("destination");
		int weight = Integer.parseInt(request.getParameter("weight"));

		BookDto bookDto = new BookDto();
		bookDto.setName(name);
		bookDto.setType(type);
		bookDto.setPickup(pickup);
		bookDto.setDestination(destination);
		bookDto.setWeight(weight);

		BookDao bookDao = new BookDao();
		Boolean check = bookDao.run(bookDto);

		if (check) {
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Courier booked successfully');");
			out.println("location='customer.jsp';");
			out.println("</script>");
		} else {
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Please try again');");
			out.println("location='customer.jsp';");
			out.println("</script>");
		}

	}

}
