package com.yash.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.yash.dto.TrackDto;

public class TrackDao {
	public ResultSet run(TrackDto trackDto) {
		int id=trackDto.getId();
		if (id!=0) {
			try {
				DBConnectivity dc = new DBConnectivity();
				Connection con = dc.getConnectivity();

				Statement st = con.createStatement();
				ResultSet set = st.executeQuery("Select * from courier_details where id="+id);
				return set;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
