package com.yash.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.courierManagementSystem.DBConnectivity;
import com.yash.dto.AdminDto;

public class AdminDao {

	public Boolean validate(AdminDto adminDto) {
		Boolean check = false;
		String username = adminDto.getUsername();
		String password = adminDto.getPassword();
		System.out.println(username + password);
		DBConnectivity dc = new DBConnectivity();
		Connection con;
		try {
			con = dc.getConnectivity();
			Statement st = con.createStatement();
			ResultSet set = st.executeQuery("Select * from admin");
			while (set.next()) {
				if (username.equals(set.getString(1)) && password.equals(set.getString(2))) {
					return true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return check;
	}

	public ResultSet run(AdminDto adminDto) {
		AdminDao adminDao = new AdminDao();
		if (adminDao.validate(adminDto)) {
			try {
				DBConnectivity dc = new DBConnectivity();
				Connection con = dc.getConnectivity();

				Statement st = con.createStatement();
				ResultSet set = st.executeQuery("Select * from courier_details");
				return set;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
