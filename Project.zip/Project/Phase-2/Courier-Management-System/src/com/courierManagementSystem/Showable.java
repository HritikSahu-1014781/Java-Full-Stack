package com.courierManagementSystem;

interface Showable
{
	void show();
}