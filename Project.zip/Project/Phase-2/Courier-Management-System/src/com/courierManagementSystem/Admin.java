package com.courierManagementSystem;

import java.sql.*;
import java.util.Scanner;
import java.io.Console;

class Admin extends CourierDetails implements Showable
{
	public void show() 
	{
		try
		{
			DBConnectivity dc = new DBConnectivity();
			Connection con=dc.getConnectivity();
			
			Statement st=con.createStatement();
			
			
			while(true)
			{
				Scanner sc=new Scanner(System.in);
				System.out.println("Please enter the Username");
				//sc.nextLine();
				String username= sc.nextLine();
				System.out.println("Please enter the Password");
				String password=sc.nextLine();
				System.out.println("-------------------------------");
				int count=0;
				
				ResultSet set =st.executeQuery("Select * from admin");
				while(set.next())
				{
					if(username.equals(set.getString(1))&&password.equals(set.getString(2)))
					{
						count++;
					}
				}
				if(count==0)
				{
					System.out.println("Please try again the Username and Password is Invalid");
					System.out.println("-------------------------------");
					continue;
				}
				else
				{
					DisplayCourier display=new DisplayCourier();
					display.show();
					CourierService service=new CourierService();
					service.run();
					break;
				}
			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}