package com.courierManagementSystem;

import java.util.Scanner;
import java.sql.*;

class Customer extends CourierDetails implements Showable
{
	public void show()
	{
		while(true)
		{
			System.out.println("Press 1 for Courier Details");
			System.out.println("Press 2 for Courier with us");
			System.out.println("Press 3 for Contact Us ");
			System.out.println("Press 4 for Previous Menu");
			System.out.println("Press 5 for Exit");
			
			System.out.println("-------------------------------");

			
			Scanner sc=new Scanner(System.in);
			int input=sc.nextInt();
			System.out.println("-------------------------------");
			
			if(input>5||input<=0)
			{
				System.out.println("Please enter a valid input.");
				continue;
			}
			
			if(input==5)
			{
				System.out.println("Thank you !");
				System.exit(0);
			}
			Customer courier=new Customer();
			switch(input)
			{
				case 1: System.out.println("Please enter Courier ID: ");
				        int id=sc.nextInt();
						System.out.println("-------------------------------");
						
						try
						{
							DBConnectivity dc = new DBConnectivity();
							Connection con=dc.getConnectivity();
							
							Statement st=con.createStatement();
							ResultSet set =st.executeQuery("Select * from courier_details");
							int count=0;
							while(set.next())
							{
								if(id==(set.getInt(1)))
								{
									System.out.printf("\n%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n","Courier ID","Courier Name","Courier Type","Pickup Location","Destination","Weight","Amount");
									System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n",set.getInt(1),set.getString(2),set.getString(3),set.getString(4),set.getString(5),set.getInt(6)+" g.",set.getInt(7)+" rs.");
									count++;
									break;
								}
							}
							if(count==0)
							{
								System.out.println("No courier from this Courier Id.");
								break;
							}
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
						break;
						
				case 2: courier.bookCourier();
						break;
				case 3: System.out.println("Please Contact Us on:\nCall: +91 12345 67890\nEmail: help.courier_service@gmail.com");
						break;
				case 4: CourierService cs=new CourierService();
				        cs.run();

			}
			System.out.println("-------------------------------");
		}
	}
}