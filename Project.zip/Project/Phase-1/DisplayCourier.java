import javax.swing.JTable; 
import javax.swing.JFrame; 
import javax.swing.JScrollPane; 
import java.sql.*;
import java.awt.Font;
import javax.swing.table.JTableHeader;

class DisplayCourier
{
	public void show()  
	{  
		try
		{
			DBConnectivity dc = new DBConnectivity();
			Connection con=dc.getConnectivity();
			
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery("Select count(*) from courier_details");
			int size=0;
			while(set.next())
			{
				size=set.getInt(1);
			}
			String[][] arr=new String[size][7];
			String[] column={"Courier ID","Courier Name","Courier Type","Pickup Location","Destination","Weight(In grams)","Amount(In Rupees)"};
			
			while(true)
			{
				set=st.executeQuery("Select * from courier_details");
				
				int a=0;
				while(set.next())
				{
					arr[a][0]=" "+set.getInt(1);
					arr[a][1]=" "+set.getString(2);
					arr[a][2]=" "+set.getString(3);
					arr[a][3]=" "+set.getString(4);
					arr[a][4]=" "+set.getString(5);
					arr[a][5]=" "+set.getInt(6);
					arr[a][6]=" "+set.getInt(7);
					a++;
				}
				JFrame f= new JFrame("Courier Service"); 
				
				JTable j = new JTable(arr, column);
				j.setFont(new Font("Calibri", Font.PLAIN, 20));
	
                JTableHeader tableHeader = j.getTableHeader();
				tableHeader.setFont(new Font("Calibri", Font.BOLD, 23));
				
				j.setRowHeight(30);
				
				JScrollPane sp = new JScrollPane(j);
				f.add(sp);
				
				f.setSize(1400,600);
				f.setExtendedState(JFrame.MAXIMIZED_BOTH);
			
				f.setVisible(true);
				//f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				break;
			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}   
}  