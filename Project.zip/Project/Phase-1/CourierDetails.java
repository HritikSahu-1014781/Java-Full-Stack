import java.util.Scanner;
import java.sql.*;

abstract class CourierDetails
{
	void bookCourier()
	{
		try
		{
			DBConnectivity dc = new DBConnectivity();
			Connection con=dc.getConnectivity();
			String q="insert into courier_details(customer_name,courier_type,pickup_location,destination,weight,amount) values(?,?,?,?,?,?)";
			PreparedStatement st=con.prepareStatement(q);
			
			Scanner sc=new Scanner(System.in);
			
			System.out.println("Please enter your name: ");
			st.setString(1,sc.nextLine());
			
			System.out.println("Please enter the Courier type: ");
			st.setString(2,sc.nextLine());
			
			System.out.println("Please enter Pickup Location: ");
			st.setString(3,sc.nextLine());
			
			System.out.println("Please enter Destination: ");
			st.setString(4,sc.nextLine());
			
			System.out.println("Please enter Weight(In Grams): ");
			int weight=sc.nextInt();
			st.setInt(5,weight);
			
			CalculateAmount amount=new CalculateAmount();
			st.setDouble(6,amount.calculate(weight));
			
			st.executeUpdate();
			
			Statement stm=con.createStatement();
			ResultSet set =stm.executeQuery("Select * from courier_details where id=(Select max(id) from courier_details)");
	
			System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n\n","Courier ID","Courier Name","Courier Type","Pickup Location","Destination","Weight","Amount");
			while(set.next())
			{
				System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n",set.getInt(1),set.getString(2),set.getString(3),set.getString(4),set.getString(5),set.getInt(6)+" g.",set.getInt(7)+" rs.");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*{
		Scanner sc=new Scanner(System.in);
		
		courier[a][0]=""+(a+1)+"";
		System.out.println("Please enter the Courier type: ");
		setType(sc.nextLine(),a,1);
		System.out.println("Please enter your name: ");
		setName(sc.nextLine(),a,2);
		System.out.println("Please enter Pickup Location: ");
		setPickup(sc.nextLine(),a,3);
		System.out.println("Please enter Destination: ");
		setDestination(sc.nextLine(),a,4);
		courier[a][5]=""+(new Random().nextInt(200)+50);
		
		System.out.printf("\n%-25s%-25s%-25s%-25s%-25s%-25s\n\n","Courier ID","Courier Type","Courier Name","Pickup Location","Destination","Amount");
		System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s\n",courier[a][0],courier[a][1],courier[a][2],courier[a][3],courier[a][4],courier[a][5]);
		a++;
	}
	void setType(String type,int a,int b)
	{
		this.courier[a][b]= type;
	}
	void setName(String name,int a,int b)
	{
		this.courier[a][b]= name;
	}
	void setPickup(String pickup,int a,int b)
	{
		this.courier[a][b]= pickup;
	}
	void setDestination(String destination,int a,int b)
	{
		this.courier[a][b]= destination;
	}*/
