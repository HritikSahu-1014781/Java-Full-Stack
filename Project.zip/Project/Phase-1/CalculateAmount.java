class CalculateAmount
{
	public double calculate(int weight)
	{
		return weight*0.25;
	}
}