import java.util.Scanner;

class CourierService
{
	CourierService()
	{
		System.out.println("\nWelcome to Courier Services !\n");
	}
	
	void run()
	{
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Press 1 for Admin login");
		System.out.println("Press 2 for Customer login");
		System.out.println("Press 3 for Exit");
		System.out.println("-------------------------------");
		
		switch(sc.nextInt())
		{
			case 1: System.out.println("-------------------------------");
					Admin admin=new Admin();
					admin.show();
					break;
					
			case 2: System.out.println("-------------------------------");
					Customer customer=new Customer();
					customer.show();
					break;
					
			case 3: System.out.println("-------------------------------");
			        System.out.println("Thank you!");
					System.exit(0);
		}
	}
	public static void main(String [] args)
	{
		CourierService cs=new CourierService();
		cs.run();
	}
}