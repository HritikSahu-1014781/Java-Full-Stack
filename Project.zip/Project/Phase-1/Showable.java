interface Showable
{
	void show();
}