import java.sql.*;
import java.io.FileInputStream;

class DBConnectivity
{
	public Connection getConnectivity() throws Exception
	{
		FileInputStream f=new FileInputStream("C:/Users/Hritik.Sahu/Desktop/Project/Connection.txt");
		
		String str="";
		int c;
		while((c=f.read())!=-1)
		{
			str=str.concat(String.valueOf((char)c));
		}
		
		String[] s=str.split(" ");
		
		String url=s[0];
		String username=s[1];
		String password=s[2];
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,username,password);
		return con;
	}
}
