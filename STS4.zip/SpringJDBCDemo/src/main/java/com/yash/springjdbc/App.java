package com.yash.springjdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;

public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		StudentDao stdao = context.getBean("StudentDao", StudentDao.class);

		Student s = new Student();
		s.setId(101);
		s.setName("Hritik");
		int r = stdao.insert(s);
		System.out.println(r + "Student added Successfully ");
		
		int r1=stdao.updatedetails(s);
		System.out.println(r1 + "Student updated Successfully ");
		
		int r2=stdao.deletedetails(108);
		System.out.println(r2 + "Student deleted Successfully ");
		
		Student out=stdao.selectDetails(111);
		System.out.println(out);
		
		List<Student> stu=stdao.getAllDetails();
		for(Student s1:stu)
		{
		System.out.println(s1);
		}
	}
}
