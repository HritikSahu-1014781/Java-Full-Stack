package com.yash.springjdbc;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;

public class Insert {

	public void run()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		StudentDao stdao = context.getBean("StudentDao", StudentDao.class);

		Scanner sc =new Scanner(System.in);
		Student s = new Student();
		
		System.out.println("Please enter the the Student Name");
		s.setName(sc.nextLine());
		
		int r = stdao.insert(s);
		System.out.println(r + "Student added Successfully ");
		
		App ap=new App();
		ap.run();
	}
}
