package com.yash.springjdbc;

import java.util.Scanner;

public class App {

	public void run() {
		Scanner sc = new Scanner(System.in);
		System.out.println("\nWelcome to Database !\n");

		System.out.println("Press 1 for Insert");
		System.out.println("Press 2 for Update");
		System.out.println("Press 3 for Delete");
		System.out.println("Press 4 for Select");
		System.out.println("Press 5 for Exit");

		switch (sc.nextInt()) {
		case 1:
			Insert i = new Insert();
			i.run();
			break;
		case 2:
			Update u = new Update();
			u.run();
			break;
		case 3:
			Delete d = new Delete();
			d.run();
			break;
		case 4:
			Select s = new Select();
			s.run();
			break;
		case 5:
			System.exit(0);
		}
	}

	public void validate() {
		int count = 0;
		while (count == 0) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Please enter the Username:");
			String username = sc.nextLine();
			if (username.equals("Hritik")) {
				while (count == 0) {
					System.out.println("Please enter the Password:");
					String password = sc.nextLine();

					if (password.equals("12345")) {
						count = 1;
					} else {
						System.out.println("Incorrect Password\n");
					}
				}
			} else {
				System.out.println("Incorrect Username\n");
			}
		}
	}

	public static void main(String[] args) {

		App ap = new App();
		ap.validate();
		ap.run();

	}
}
