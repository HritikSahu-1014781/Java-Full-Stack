package com.yash.springjdbc;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;

public class Update {
	
	public void run()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		StudentDao stdao = context.getBean("StudentDao", StudentDao.class);
		Student s = new Student();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please enter Student Id to Update:");
		int id=sc.nextInt();
		
		System.out.println("Please enter the new name:");
		sc.nextLine();
		String name=sc.nextLine();
		
		int r1 = stdao.updatedetails(s,id,name);
		System.out.println(r1 + "Student updated Successfully ");
		
		App ap=new App();
		ap.run();
	}

}
