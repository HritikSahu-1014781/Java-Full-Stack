package com.yash.springjdbc;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;

public class Delete {
	public void run() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		StudentDao stdao = context.getBean("StudentDao", StudentDao.class);
		Student s = new Student();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please enter Student Id to Delete:");
		int r2 = stdao.deletedetails(sc.nextInt());
		System.out.println(r2 + "Student deleted Successfully ");
		
		App ap=new App();
		ap.run();
	}
}
