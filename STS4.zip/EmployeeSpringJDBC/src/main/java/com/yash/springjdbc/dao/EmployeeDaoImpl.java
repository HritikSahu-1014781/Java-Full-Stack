package com.yash.springjdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.entities.*;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbctemp;

	public int insert(Employee ep) {

		String q = "insert into employee(empname,emailid,dob,contactno,salary) values(?,?,?,?,?)";
		int msg = this.jdbctemp.update(q,ep.getName(),ep.getEmailId(),ep.getDob(),ep.getContactNo(),ep.getSalary());
		return msg;
	}

	public int updatedetails(Employee ep) {
		// update details of student
		String q = "update employee set emailid=? where empname=?";
		int msg = this.jdbctemp.update(q, ep.getEmailId(), ep.getName());

		return msg;
	}

	public int deletedetails(String epname) {
		String q = "delete from employee where empname=?";
		int msg = this.jdbctemp.update(q, epname);

		return msg;
	}

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

}
