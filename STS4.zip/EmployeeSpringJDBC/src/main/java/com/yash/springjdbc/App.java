package com.yash.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.EmployeeDao;
import com.yash.springjdbc.entities.Employee;

public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		EmployeeDao epdao = context.getBean("EmployeeDao", EmployeeDao.class);

		Employee s = new Employee();
		
		s.setName("Hritik");
		s.setEmailId("hritik.sahu@yash.com");
		s.setDob("16/05/2001");
		s.setContactNo(94);
		s.setSalary(10000);
		
		int r = epdao.insert(s);
		System.out.println(r + "Employee added Successfully ");
		
		int r1=epdao.updatedetails(s);
		System.out.println(r1 + "Employee updated Successfully ");
		
		int r2=epdao.deletedetails("Jaynam");
		System.out.println(r2 + "Employee deleted Successfully ");
	}
}

