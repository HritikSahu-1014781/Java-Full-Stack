package com.yash.springjdbc.entities;

public class Employee {

	private String name;
	private String emailId;
	private String dob;
	private int contactNo;
	private int salary;

	public Employee(String name, String emailId, String dob, int contactNo, int salary) {
		super();
		this.name = name;
		this.emailId = emailId;
		this.dob = dob;
		this.contactNo = contactNo;
		this.salary = salary;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getContactNo() {
		return contactNo;
	}

	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Employee() {
		super();

	}

}
